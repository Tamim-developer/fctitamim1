<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="css/register.css">
</head>
<body>
       <div class="register_container">
        <form action="" method="POST" class="register_form">
            <h1>Register</h1>

        <label for="">User Role</label>
        <select name="role" required>
            <option value="" style="color: gray;">Select</option>
            <option value="teacher">Teacher</option>
            <option value="staff">Staff</option>
            <option value="editor">Editor</option>
            <option value="admin">Admin</option>
        </select>

            <input name="username" type="text" placeholder="username">

            <input name="email" type="text" placeholder="Enter your email">

            <input name="password" type="password" placeholder="New password">

            <input name="confirm_password" type="password" placeholder="Confirm new password">
        
            <input name="submit" type="submit" value="Submit" class="button">

            <p>Already have an account? <a href="login.php">Login</a></p>
        </form>
    </div> 
</body>
</html>