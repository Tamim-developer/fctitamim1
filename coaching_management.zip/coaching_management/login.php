<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="css/login.css">
    <!-- Google font link -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Edu+NSW+ACT+Cursive:wght@400..700&family=Roboto:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet"> 
</head>
<body>
    <form action="" class="login_form">
        <h1>Login</h1>

        <label for="">User Role</label>
        <select name="role" required>
            <option value="" style="color: gray;">Select</option>
            <option value="teacher">Teacher</option>
            <option value="staff">Staff</option>
            <option value="editor">Editor</option>
            <option value="admin">Admin</option>
        </select>

        <label for="">Username</label>
        <input type="text" placeholder="username">

        <label for="">Password</label>
        <input type="password" placeholder="Password" required>

        <a href=""><button>Login</button></a>

        <p>Forget password ? <a href="">Click Here</a></p>
        <p>Don't have an account ? <a href="register.php">Click Here</a></p>
    </form>
</body>
</html>