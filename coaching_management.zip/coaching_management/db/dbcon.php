<?php
$host = 'localhost';
$username = 'root';
$password = '';
$dbname = 'coaching_management';
$dbcon = mysqli_connect($host, $username, $password, $dbname);
?>